SMARTCLINIC - COMPLETE FLASK PROJECT

1. Open this folder in VS Code.
2. Open Terminal in the project folder.
3. Install packages:
   pip install -r requirements.txt
4. Run:
   python app.py
5. Open:
   http://127.0.0.1:5000

DATABASE:
- SQLite database.db is created automatically.
- Users, doctors and appointments are stored in database.db.
- Existing database columns are migrated for doctors.user_id.

DEMO DOCTOR ACCOUNTS:
Dr. Anil Kumar
Email: anil@smartclinic.com
Password: anil123

Dr. Priya Sharma
Email: priya@smartclinic.com
Password: priya123

Dr. Rahul Verma
Email: rahul@smartclinic.com
Password: rahul123

Dr. Sneha Rao
Email: sneha@smartclinic.com
Password: sneha123

PATIENT:
Register from the website.

FEATURES:
- Patient registration/login/logout
- Secure password hashing
- Doctor accounts
- Doctor-specific availability
- 30-minute appointment slots
- Double-booking prevention
- Patient appointment list
- Edit appointment
- Cancel appointment
- Doctor dashboard
- Doctor complete/cancel status
- Profile update and password change
- Admin dashboard route (requires an admin user)
